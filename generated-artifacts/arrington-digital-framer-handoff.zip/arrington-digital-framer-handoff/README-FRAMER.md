# Arrington Digital — Framer handoff

This archive contains the complete Arrington Digital website source and its local images and video.

## Contents

- `website-source/src/` — page content, route handling, interactions, and styles
- `website-source/public/images/` — website images and product visuals
- `website-source/public/videos/` — homepage hero reel
- `website-source/public/sitemap.xml` — page URL inventory
- `website-source/public/robots.txt` — crawler instructions

## Using this with Framer

This is a React/Vite website source archive, not a native Framer project. Framer's documented workflows import selected layers from Figma or copy selected sections from a live website; they do not describe importing an arbitrary full-site ZIP as editable Framer pages.

Use the images and video under `website-source/public/` as uploadable assets in Framer. Use the source files and sitemap as references for page copy, route structure, and interactions.

Official Framer guide: https://www.framer.com/academy/lessons/framer-fundamentals-importing-from-figma-and-the-web

## Notes

- `node_modules`, build output, and Replit-only artifact configuration are not included.
- This package contains no secrets or environment values.
